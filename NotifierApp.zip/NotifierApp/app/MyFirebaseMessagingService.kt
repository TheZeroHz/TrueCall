package com.example.notifierapp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        Log.d("FCM", "Message received from: ${remoteMessage.from}")

        // Check if message contains data payload
        if (remoteMessage.data.isNotEmpty()) {
            Log.d("FCM", "Message data payload: ${remoteMessage.data}")

            val department = remoteMessage.data["department"]
            val office = remoteMessage.data["office"]
            val role = remoteMessage.data["role"]
            val topic = remoteMessage.data["topic"] ?: "Someone is calling"

            // Check if this notification is for the registered user
            val sharedPrefs = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
            val userDept = sharedPrefs.getString("department", "")
            val userOffice = sharedPrefs.getString("office", "")
            val userRole = sharedPrefs.getString("role", "")

            if (department == userDept && office == userOffice && role == userRole) {
                triggerVibration()
                showNotification("Calling Bell Alert", topic)
            }
        }

        // Check if message contains notification payload
        remoteMessage.notification?.let {
            Log.d("FCM", "Message Notification Body: ${it.body}")
            showNotification(it.title ?: "Calling Bell", it.body ?: "Someone is calling you")
        }
    }

    override fun onNewToken(token: String) {
        Log.d("FCM", "Refreshed token: $token")
        // Send token to your server here if needed
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Calling Bell Channel"
            val descriptionText = "Channel for calling bell notifications"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel("calling_bell_channel", name, importance).apply {
                description = descriptionText
                enableVibration(true)
            }

            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun triggerVibration() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        if (vibrator?.hasVibrator() == true) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Strong calling bell pattern
                val vibrationEffect = VibrationEffect.createWaveform(
                    longArrayOf(0, 800, 200, 800, 200, 800),
                    -1 // Don't repeat
                )
                vibrator.vibrate(vibrationEffect)
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(1000)
            }
        }
    }

    private fun showNotification(title: String, message: String) {
        val notificationId = System.currentTimeMillis().toInt()
        val builder = NotificationCompat.Builder(this, "calling_bell_channel")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setVibrate(longArrayOf(0, 800, 200, 800))

        try {
            with(NotificationManagerCompat.from(this)) {
                notify(notificationId, builder.build())
            }
        } catch (e: Exception) {
            Log.e("FCM", "Error showing notification", e)
        }
    }
}