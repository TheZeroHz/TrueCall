package com.example.notifierapp

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.notifierapp.ui.theme.NotifierAppTheme
import com.google.firebase.database.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var sharedPreferences: SharedPreferences
    private var currentUserRole: String? = null
    private var currentDepartment: String? = null
    private var currentOffice: String? = null

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        // Handle permission result if needed
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Firebase Database
        database = FirebaseDatabase.getInstance("https://smartringer-b177554654-default-rtdb.asia-southeast1.firebasedatabase.app/").reference

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)

        // Load saved user data
        loadUserData()

        // Create notification channel
        createNotificationChannel()

        // Request notification permission for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        setContent {
            NotifierAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    if (currentUserRole.isNullOrEmpty()) {
                        UserRegistrationScreen { dept, office, role ->
                            registerUser(dept, office, role)
                        }
                    } else {
                        MainScreen()
                    }
                }
            }
        }

        // Start listening to Firebase if user is registered
        if (!currentUserRole.isNullOrEmpty()) {
            startListeningToFirebase()
        }
    }

    private fun loadUserData() {
        currentDepartment = sharedPreferences.getString("department", null)
        currentOffice = sharedPreferences.getString("office", null)
        currentUserRole = sharedPreferences.getString("role", null)
    }

    private fun registerUser(department: String, office: String, role: String) {
        currentDepartment = department
        currentOffice = office
        currentUserRole = role

        // Save to SharedPreferences
        with(sharedPreferences.edit()) {
            putString("department", department)
            putString("office", office)
            putString("role", role)
            apply()
        }

        // Start listening to Firebase
        startListeningToFirebase()

        // Recreate activity to show main screen
        recreate()
    }

    private fun startListeningToFirebase() {
        if (currentDepartment == null || currentOffice == null || currentUserRole == null) return

        val path = "$currentDepartment/$currentOffice/$currentUserRole"
        Log.d("FirebaseListener", "Listening to path: $path")

        database.child(path).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                try {
                    val calling = snapshot.child("Calling").getValue(Boolean::class.java) ?: false
                    val topic = snapshot.child("Topic").getValue(String::class.java) ?: "No message"

                    Log.d("FirebaseListener", "Calling: $calling, Topic: $topic")

                    if (calling && topic != "NONE") {
                        triggerNotificationAndVibration(topic)
                    }
                } catch (e: Exception) {
                    Log.e("FirebaseListener", "Error processing data", e)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("FirebaseListener", "Database error: ${error.message}")
            }
        })
    }

    private fun triggerNotificationAndVibration(message: String) {
        triggerVibration()
        showNotification("Calling Bell Alert", message)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Calling Bell Channel"
            val descriptionText = "Channel for calling bell notifications"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel("calling_bell_channel", name, importance).apply {
                description = descriptionText
                enableVibration(true)
                setSound(null, null) // We'll handle vibration manually
            }

            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun triggerVibration() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        if (vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Strong calling bell pattern: long vibrations
                val vibrationEffect = VibrationEffect.createWaveform(
                    longArrayOf(0, 800, 200, 800, 200, 800),
                    -1 // Don't repeat
                )
                vibrator.vibrate(vibrationEffect)
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(1000) // Vibrate for 1 second
            }
        }
    }

    private fun showNotification(title: String, message: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
        }

        val notificationId = System.currentTimeMillis().toInt()
        val builder = NotificationCompat.Builder(this, "calling_bell_channel")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setVibrate(longArrayOf(0, 800, 200, 800))

        with(NotificationManagerCompat.from(this)) {
            notify(notificationId, builder.build())
        }
    }
}

@Composable
fun UserRegistrationScreen(onRegister: (String, String, String) -> Unit) {
    var selectedDepartment by remember { mutableStateOf("BUBT") }
    var selectedOffice by remember { mutableStateOf("VCOffice") }
    var selectedRole by remember { mutableStateOf("") }

    val departments = listOf("BUBT")
    val offices = listOf("VCOffice", "Registrar", "Accounts", "IT")
    val roles = listOf("PA", "PION", "PS", "Staff", "Officer")

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Register for Calling Bell",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 24.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Department Selection
                Text(
                    text = "Department:",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
                departments.forEach { dept ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = selectedDepartment == dept,
                                onClick = { selectedDepartment = dept }
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedDepartment == dept,
                            onClick = { selectedDepartment = dept }
                        )
                        Text(text = dept, modifier = Modifier.padding(start = 8.dp))
                    }
                }

                HorizontalDivider()

                // Office Selection
                Text(
                    text = "Office:",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
                offices.forEach { office ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = selectedOffice == office,
                                onClick = { selectedOffice = office }
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedOffice == office,
                            onClick = { selectedOffice = office }
                        )
                        Text(text = office, modifier = Modifier.padding(start = 8.dp))
                    }
                }

                HorizontalDivider()

                // Role Selection
                Text(
                    text = "Your Role:",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
                roles.forEach { role ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = selectedRole == role,
                                onClick = { selectedRole = role }
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedRole == role,
                            onClick = { selectedRole = role }
                        )
                        Text(text = role, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                if (selectedRole.isNotEmpty()) {
                    onRegister(selectedDepartment, selectedOffice, selectedRole)
                }
            },
            enabled = selectedRole.isNotEmpty(),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = "Register & Start Listening",
                style = MaterialTheme.typography.titleMedium
            )
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
fun MainScreen() {
    val context = LocalContext.current
    val sharedPrefs = context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
    val department = sharedPrefs.getString("department", "N/A")
    val office = sharedPrefs.getString("office", "N/A")
    val role = sharedPrefs.getString("role", "N/A")

    var connectionStatus by remember { mutableStateOf("Connecting...") }
    var lastMessage by remember { mutableStateOf("Waiting for calls...") }

    LaunchedEffect(Unit) {
        delay(2000)
        connectionStatus = "Connected ✓"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Calling Bell System",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = connectionStatus,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (connectionStatus.contains("✓")) Color(0xFF4CAF50) else Color(0xFFFF9800)
                )
            }
        }

        // User Info
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Your Registration:",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text("Department: $department")
                Text("Office: $office")
                Text("Role: $role")
            }
        }

        // Status
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Status:",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = "🔔 Listening for calls to $role in $office",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = "Last update: $lastMessage",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Reset Button
        OutlinedButton(
            onClick = {
                with(sharedPrefs.edit()) {
                    clear()
                    apply()
                }
                (context as ComponentActivity).recreate()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Reset Registration")
        }
    }
}